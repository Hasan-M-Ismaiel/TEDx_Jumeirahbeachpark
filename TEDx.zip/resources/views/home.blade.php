@extends('layouts.app')

@section('content')
<div class="body flex-grow-1 px-3 main-img test">
    <div class="container-lg ">
        <div class="container">
            <div class="row justify-content-center">
                <div class="row">
                </div>
            </div>
        </div>
    </div>
</div>

@endsection