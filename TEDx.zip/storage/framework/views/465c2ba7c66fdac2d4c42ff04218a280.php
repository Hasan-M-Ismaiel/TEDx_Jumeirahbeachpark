<?php $__env->startSection('content'); ?>
<div class="body flex-grow-1 px-3 test mt-4">
    <div class="container-lg ">
        <div class="container mb-3">
            <div class="row justify-content-center">
                <div class="card p-5">
                    <div class="container-fluid border my-3  ">
                        <div class="row justify-content-center">
                            <div class="card-create-project pt-4 my-3 mx-5 px-5">
                                <h2 id="heading">Deleting Register</h2>
                                <p id="pcreateProject">success message</p>
                                <form id="msform" action='<?php echo e(route("admin.registers.update", $register)); ?>' method="POST">
                                    <?php echo csrf_field(); ?>
                                    <!-- fieldsets -->
                                    <!--stage four-->
                                    <fieldset class="active">
                                        <div class="form-card">
                                            <h2 class="purple-text text-center"><strong>SUCCESS !</strong></h2>
                                            <br>
                                            <div class="row justify-content-center">
                                                <div class="col-3">
                                                    <img src="<?php echo e(asset('assets/images/success.png')); ?>" class="fit-image">
                                                </div>
                                            </div>
                                            <br><br>
                                            <div class="row justify-content-center">
                                                <div class="col-7 text-center">
                                                    <h5 class="purple-text text-center">Register <strong><?php echo e($register); ?></strong> has been deleted successfully</h5>
                                                    <h5 class="purple-text text-center">Now <strong><?php echo e(ucfirst(auth()->user()->name)); ?></strong>, What is your next step? go <a href="<?php echo e(route('admin.registers.index')); ?>">home?</a></h5>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel_projects\15_5_2024_TEDx_project\TEDx\resources\views/admin/success_messages/success_delete_register.blade.php ENDPATH**/ ?>