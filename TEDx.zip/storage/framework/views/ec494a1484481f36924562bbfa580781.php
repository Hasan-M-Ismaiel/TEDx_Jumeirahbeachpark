	
<div class="loading" id="loading" style="display: none;">Loading&#8230;</div>
<?php /**PATH C:\Apache24\htdocs\laravel_projects\15_5_2024_TEDx_project\TEDx\resources\views/components/loader.blade.php ENDPATH**/ ?>