<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Apache24\htdocs\laravel_projects\15_5_2024_TEDx_project\TEDx\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>