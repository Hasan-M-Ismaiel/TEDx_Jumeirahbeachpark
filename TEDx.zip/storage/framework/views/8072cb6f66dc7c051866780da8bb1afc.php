<?php $__env->startSection('content'); ?>
<div class="body flex-grow-1 px-3 main-img test">
    <div class="container-lg ">
        <div class="container">
            <div class="row justify-content-center">
                <div class="row">
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel_projects\15_5_2024_TEDx_project\TEDx\resources\views/home.blade.php ENDPATH**/ ?>