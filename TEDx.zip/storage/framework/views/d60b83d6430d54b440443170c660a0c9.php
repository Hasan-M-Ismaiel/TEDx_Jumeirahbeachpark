<?php $__env->startSection('content'); ?>
<div class="body flex-grow-1 px-3 test mt-4">
  <div class="container-lg ">
    <div class="card p-5">
      <div class="row border">
        <!--header section-->
        <div class="col">
          <div class="container-fluid my-3  ">
            <div class="row justify-content-center">
              <div class="card-create-project pt-4 my-3 mx-5 px-5">
                <h2 id="heading"><?php echo e($page); ?></h2>
                <p id="pcreateProject">dashboard to manage all created speakers</p>
                <a type="button" class="rounded" href="<?php echo e(route('admin.speakers.create')); ?>" style="text-decoration: none;" role="button">
                  <div class="action-main-create-button px-5 text-center py-3 rounded">Create New Speaker</div>
                </a>
              </div>
            </div>
          </div>
        </div>
        <!--search button section-->
        <div class="col position-relative  ">
          <div class="col mx-auto position-absolute bottom-0 end-0">
            <div class="input-group mb-3 me-3">
              <input class="form-control border-end-0 border rounded-pill" type="search" placeholder="search" id="search-input">
              <span class="input-group-append">
                <button class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" type="button" id="search_button">
                  <i class="bi bi-search"></i>
                </button>
              </span>
              <div class="btn" id="reset">reset</div>
              <a class="btn btn-primary me-2" href="<?php echo e(route('admin.exportSpeakers')); ?>" role="button">export as Excel</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php if($speakers->count()>0): ?>
    <!--users table section-->
    <?php if (isset($component)) { $__componentOriginal99b56bab5c8fb51d1e0e87c6be8b8804 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99b56bab5c8fb51d1e0e87c6be8b8804 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.speakers-table','data' => ['speakers' => $speakers]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('speakers-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['speakers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($speakers)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99b56bab5c8fb51d1e0e87c6be8b8804)): ?>
<?php $attributes = $__attributesOriginal99b56bab5c8fb51d1e0e87c6be8b8804; ?>
<?php unset($__attributesOriginal99b56bab5c8fb51d1e0e87c6be8b8804); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99b56bab5c8fb51d1e0e87c6be8b8804)): ?>
<?php $component = $__componentOriginal99b56bab5c8fb51d1e0e87c6be8b8804; ?>
<?php unset($__componentOriginal99b56bab5c8fb51d1e0e87c6be8b8804); ?>
<?php endif; ?>
    <?php else: ?>
    <h5 class="text-center"> <span class="badge m-1" style="background: #673AB7;" id="no_notifications">There is no speakers now!</span> </h5>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel_projects\15_5_2024_TEDx_project\TEDx\resources\views/admin/speakers/index.blade.php ENDPATH**/ ?>