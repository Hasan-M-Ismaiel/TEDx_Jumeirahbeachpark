<button type="submit" class="action-create-button" onclick="showSpinner()">
    <span id="spinner" class="spinner-border spinner-border-sm" role="status" aria-hidden="true" style="display: none;"></span>
    Update
</button>

<script>
   function showSpinner(){
        $('#spinner').show();
        // $('#create-button').text('updating...');
    }
</script><?php /**PATH C:\Apache24\htdocs\laravel_projects\15_5_2024_TEDx_project\TEDx\resources\views/components/forms/update-button.blade.php ENDPATH**/ ?>